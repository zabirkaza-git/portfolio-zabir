# Muhammad Zabir Portfolio Website

## Preview
Open `index.html` in a web browser.

## Deploy to GitHub Pages
1. Create a new GitHub repository (for example `zabir-portfolio`).
2. Upload `index.html` to the repository root.
3. Go to Settings → Pages.
4. Under Build and deployment, select Deploy from a branch, choose `main` and `/ (root)`, then Save.
5. After deployment, GitHub will show the public website URL.

## Before publishing
- Confirm the education details. The supplied resume says Diploma in Computer Science at UiTM Tapah, Sept 2024–Present, CGPA 3.81; it does not state a completed Bachelor's degree.
- Add screenshots/images of each website and project if available.
- Consider whether to publish your phone number. This draft uses email and LinkedIn only.
